from django.apps import AppConfig


class StudentRegisterConfig(AppConfig):
    name = 'student_register'
